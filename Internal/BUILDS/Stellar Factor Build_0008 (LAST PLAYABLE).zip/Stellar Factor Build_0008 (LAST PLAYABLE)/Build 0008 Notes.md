
# Stellar Factor | Build 0008
> The number of changes since the last release merge is staggering.  I'll do my best to capture the main points. <br>
> -Layla

## Art
### Textured artifacts
- Ana's artifacts
    - Textured
    - Colored
    - In use
- Gustavo's artifact (only have one)
    - Staff of Ra
    - Is in game, not in use.
    - Located near a rock behind the Book of the Dead dupe by end of level.

## Fully Working Minimap
### Nodes
- Death Location
- Artifacts
    - Change color when question been attempted but abandoned
    - Destroyed when completed
    - Destroyed when leave range
    - Re-instantiated when re-enter range (remembers state)

## UI
### Intro panels
- Two intro panels open the game
-  Created `PanelCycler` to manage this.
    - Cycles through UI panels
    - Option to clamp at the edges or cycle through to beginning
### Pause
- Fixed broken buttons on pause menu
- Pauses/control locks now have layers
    - Every time a control lock happens, a counter is incremented.
    - Counter has to equal zero before a true control unlock is achieved.
    - Counter is decremented while being checked. 
    - This allows players to access the pause menu while performing other activities that independently lock controls, including
        - Answering questions
        - Cycling through panels

## Work has begun on Level 2
### Not in a playable state
### Design is nearly complete
- Desert / Pyramid theme
- Moving platforms
- Trap doors
- Moving walls
